#ifndef GRAFO_H
#define GRAFO_H

#define MAX_PONTOS 100
#define MAX_VIZINHOS 200

typedef struct {
    char id[2];
    double x, y;
    char rua1[100];
    char rua2[100];
} Ponto;

typedef struct {
    char origem[2];
    char destino[2];
    char rua[100];
    int sentido; // 1 para direção direta, -1 para direção inversa
} Conexao;

typedef struct {
    Ponto pontos[MAX_PONTOS];
    Conexao vizinhos[MAX_VIZINHOS];
    int num_pontos;
    int num_vizinhos;
} Grafo;

void gerar_binario(const char *arquivo_pontos, const char *arquivo_vizinhos, const char *arquivo_saida);
void carregar_grafo(Grafo *grafo, const char *arquivo_bin);
void dijkstra(Grafo *grafo, const char *origem, const char *destino);

#endif // GRAFO_H
