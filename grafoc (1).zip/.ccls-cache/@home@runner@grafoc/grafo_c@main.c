#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grafo.h"

int main(int argc, char *argv[]) {
    if (argc < 4) {
        printf("Usage: %s <pontos.txt> <vizinhos.txt> <saida.bin>\n", argv[0]);
        return 1;
    }

    const char *arquivo_pontos = argv[1];
    const char *arquivo_vizinhos = argv[2];
    const char *arquivo_saida = argv[3];

    // Gera o arquivo binário com os dados do grafo
    gerar_binario(arquivo_pontos, arquivo_vizinhos, arquivo_saida);
    printf("Binary file '%s' generated successfully.\n", arquivo_saida);

    // Carrega o grafo e executa o Dijkstra interativamente
    Grafo grafo;
    carregar_grafo(&grafo, arquivo_saida);

    char origem[2], destino[2];
    printf("Enter the starting point ID (e.g., A): ");
    scanf(" %2s", origem);
    printf("Enter the destination point ID (e.g., E): ");
    scanf(" %2s", destino);

    dijkstra(&grafo, origem, destino);

    return 0;
}
