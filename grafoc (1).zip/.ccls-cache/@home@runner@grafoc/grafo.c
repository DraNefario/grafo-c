#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "grafo.h"

#define INF 99999999.0


// Função para gerar o arquivo binário
void gerar_binario(const char *arquivo_pontos, const char *arquivo_vizinhos, const char *arquivo_saida) {
    FILE *fp_pontos = fopen(arquivo_pontos, "r");
    FILE *fp_vizinhos = fopen(arquivo_vizinhos, "r");
    FILE *fp_saida = fopen(arquivo_saida, "wb");

    if (!fp_pontos || !fp_vizinhos || !fp_saida) {
        printf("Erro ao abrir arquivos.\n");
        return;
    }

    Grafo grafo = { .num_pontos = 0, .num_vizinhos = 0 };

    // Lê pontos
    while (fscanf(fp_pontos, "%2s %lf %lf %99s %99s",
                  grafo.pontos[grafo.num_pontos].id,
                  &grafo.pontos[grafo.num_pontos].x,
                  &grafo.pontos[grafo.num_pontos].y,
                  grafo.pontos[grafo.num_pontos].rua1,
                  grafo.pontos[grafo.num_pontos].rua2) != EOF) {
        grafo.num_pontos++;
    }

    // Lê conexões
    while (fscanf(fp_vizinhos, "%2s %2s %99s",
                  grafo.vizinhos[grafo.num_vizinhos].origem,
                  grafo.vizinhos[grafo.num_vizinhos].destino,
                  grafo.vizinhos[grafo.num_vizinhos].rua) != EOF) {
        grafo.vizinhos[grafo.num_vizinhos].sentido = 1;
        grafo.num_vizinhos++;
    }

    fwrite(&grafo, sizeof(Grafo), 1, fp_saida);

    fclose(fp_pontos);
    fclose(fp_vizinhos);
    fclose(fp_saida);
}

// Função para carregar o grafo do arquivo binário
void carregar_grafo(Grafo *grafo, const char *arquivo_bin) {
    FILE *fp = fopen(arquivo_bin, "rb");
    if (!fp) {
        printf("Erro ao abrir o arquivo binário.\n");
        return;
    }
    if (fread(grafo, sizeof(Grafo), 1, fp) != 1) {
        printf("Erro ao ler o arquivo binário.\n");
    }
    fclose(fp);
}



// Calcula a distância entre dois pontos
double calcular_distancia(Ponto p1, Ponto p2) {
    return sqrt(pow(p2.x - p1.x, 2) + pow(p2.y - p1.y, 2));
}

// Calcula o ângulo entre três pontos consecutivos
double calcular_angulo(Ponto p1, Ponto p2, Ponto p3) {
    double dx1 = p2.x - p1.x;
    double dy1 = p2.y - p1.y;
    double dx2 = p3.x - p2.x;
    double dy2 = p3.y - p2.y;
    double dot = dx1 * dx2 + dy1 * dy2;
    double det = dx1 * dy2 - dy1 * dx2;
    return atan2(det, dot) * 180 / M_PI;
}

// Algoritmo de Dijkstra
void dijkstra(Grafo *grafo, const char *origem, const char *destino) {
    double dist[MAX_PONTOS];
    int prev[MAX_PONTOS];
    int visited[MAX_PONTOS] = {0};
    int origem_idx = -1, destino_idx = -1;

    for (int i = 0; i < grafo->num_pontos; i++) {
        dist[i] = INF;
        prev[i] = -1;
        if (strcmp(grafo->pontos[i].id, origem) == 0) origem_idx = i;
        if (strcmp(grafo->pontos[i].id, destino) == 0) destino_idx = i;
    }

    if (origem_idx == -1 || destino_idx == -1) {
        printf("Ponto de partida ou destino inválido.\n");
        return;
    }

    dist[origem_idx] = 0;

    for (int i = 0; i < grafo->num_pontos; i++) {
        int u = -1;
        double min_dist = INF;
        for (int j = 0; j < grafo->num_pontos; j++) {
            if (!visited[j] && dist[j] < min_dist) {
                min_dist = dist[j];
                u = j;
            }
        }

        if (u == -1) break;
        visited[u] = 1;

        for (int j = 0; j < grafo->num_vizinhos; j++) {
            if (strcmp(grafo->vizinhos[j].origem, grafo->pontos[u].id) == 0) {
                int v = -1;
                for (int k = 0; k < grafo->num_pontos; k++) {
                    if (strcmp(grafo->pontos[k].id, grafo->vizinhos[j].destino) == 0) {
                        v = k;
                        break;
                    }
                }

                if (v != -1) {
                    double dist_uv = calcular_distancia(grafo->pontos[u], grafo->pontos[v]);
                    if (dist[u] + dist_uv < dist[v]) {
                        dist[v] = dist[u] + dist_uv;
                        prev[v] = u;
                    }
                }
            }
        }
    }

    int path[MAX_PONTOS];
    int path_length = 0;
    int current = destino_idx;

    if (prev[current] == -1 && current != origem_idx) {
        printf("Nenhum caminho encontrado.\n");
        return;
    }

    while (current != origem_idx) {
        path[path_length++] = current;
        current = prev[current];
    }
    path[path_length++] = origem_idx;

    printf("Para ir de %s (%s com %s) até %s (%s com %s):\n",
           grafo->pontos[origem_idx].id, grafo->pontos[origem_idx].rua1, grafo->pontos[origem_idx].rua2,
           grafo->pontos[destino_idx].id, grafo->pontos[destino_idx].rua1, grafo->pontos[destino_idx].rua2);

    for (int i = path_length - 1; i > 1; i--) {
        int current = path[i];
        int next = path[i - 1];
        int after_next = path[i - 2];

        double angle = calcular_angulo(grafo->pontos[current], grafo->pontos[next], grafo->pontos[after_next]);

        if (angle > 10) {
            printf("Em %s e %s, vire à esquerda.\n", grafo->pontos[next].rua1, grafo->pontos[next].rua2);
        } else if (angle < -10) {
            printf("Em %s e %s, vire à direita.\n", grafo->pontos[next].rua1, grafo->pontos[next].rua2);
        } else {
            printf("Continue on %s.\n", grafo->vizinhos[i].rua);
        }
    }

    printf("Você chegou em %s\n", grafo->pontos[path[0]].id);
}
